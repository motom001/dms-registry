# Änderungen

## 1.0.4

- Kurzbeschreibung in Alltagssprache, ohne Fachwörter (dms-registry #80).

## 1.0.3

- Kurzanleitung „So nutzt du es“ im Katalog und nach der Installation in Ablago (dms-registry #198, motom001/dms#1047).
- Manifest: Herausgeber `app.ablago`.

## 1.0.2

- Texte: Das Programm heißt jetzt **Ablago** (dms-registry #111). Inhalt, Rechte und Verhalten sind unverändert.

## 1.0.1

- Lizenz: ab dieser Version **Apache-2.0** (vorher MIT), wie alle Pakete von motom001. Inhalt unverändert.

## 1.0.0

- Erste Fassung: zählt neue Post, Aktion „Wie viel Post kam bisher?“.
