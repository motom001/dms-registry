# Änderungen

## 1.12.1

- **Person:** „Woran man sie erkennt“ ohne „Vollmacht“ (dms-registry #282). Vollmachten haben jetzt ein eigenes Paket **Vollmachten**; ein Update übernimmt den Text, solange ihr ihn nicht selbst geändert habt.

## 1.12.0

- **„Woran man ihn erkennt“ kürzer** (dms-registry #267): je Mappentyp vier bis sechs Wörter, die fast jedes Dokument dieses Typs enthält, statt langer Listen. Lange Listen sprachen bei Ablago oft gegen den richtigen Typ, weil jedes Dokument nur wenige ihrer Wörter enthält. Ein Update übernimmt den Text, solange ihr ihn nicht selbst geändert habt.

## 1.11.1

- Wege in der Werkbank aktualisiert: *Werkbank → Pakete → Text aus PDF und Texterkennung* bzw. *→ Archivfassung (PDF/A)* (dms-registry #262).

## 1.11.0

- **„Woran man ihn erkennt“** für jeden Mappentyp, Deutsch und Englisch (dms-registry #254): Was auf dem Papier steht – Überschriften, Begriffe, Nummern. Hilft Ablago beim Vorschlag „Wohin gehört das?“. Ein Update setzt den Text, solange ihr ihn nicht selbst geändert habt. Der Ablageort kommt nicht mehr als Vorschlag für neue Post.

## 1.10.0

- **Familie Muster jetzt in Basis** (dms-registry #225): Lena, Tom und Jonas sind Beispiel-Personen von Basis (bisher Haushalt). So können alle Pakete ihre Beispiele auf sie beziehen, etwa „Ämter & Papiere“.

## 1.9.0

- **Mehrzahl** für die Mappentypen (dms-registry #223): Listen zeigen jetzt z. B. „12 Organisationen“ statt „12 × Organisation“ (ab Ablago 0.302.0, ältere ignorieren es). Ein Update setzt die Mehrzahl nur, wo du noch keine eingetragen hast.
- **„Eigene Organisation“ nur bei beruflicher Nutzung** (dms-registry #195): Wird die Ablage nur privat genutzt, fehlen der Haken und damit auch der Abschnitt „Datenschutz“. Ein schon gesetzter Haken bleibt gespeichert.
- **„Verantwortlicher“ erklärt** (dms-registry #196): Leer heißt, die Organisation selbst ist verantwortlich – das ist der Normalfall. Die Kurzanleitung sagt das jetzt auch.
- **Neuer Tipp: Wohin mit Hinweisschreiben?** (dms-registry #228): Ein Schreiben gehört zu der Sache, um die es geht, sonst zum Absender unter „Dokumente“. Braucht Ablago 0.293.2.
- **Treffendere Symbole** der Ansichten aus den 259 Symbolen von Ablago 0.304 (dms-registry #230): Organisationen (Gebäude), Ablageorte (Archivordner). Ältere Ablago-Versionen zeigen ein neues Symbol einfach nicht.

## 1.8.0

- **Weniger Ansichten:** oben *Basis* (Symbol Kiste), darunter *Organisationen* (Gebäude), *Personen* (Personen) und *Ablageorte* (Archivkiste – der Posteingang gehört schon zu „Neue Post“). Die Ansichten *Versicherungen*, *Banken*, *Behörden*, *Ärzte und Praxen*, *Niederlassungen*, *Familie und Freunde* und *Ansprechpartner* sind weggefallen – Niederlassungen legst du an der Organisation an, den Rest findet die Suche. In bestehenden Ablagen bleiben die alten Ansichten nach einem Update stehen, bis du sie löschst.

## 1.7.2

- Beispiele ohne echt wirkende Daten (dms-registry #205): Kundenberaterin, Hausarzt und Oma heißen nach ihrer Rolle statt „Sabine Beraterin“, „Dr. Bernd Beispiel“ und „Oma Muster“; die Praxis heißt „Hausarztpraxis am Lindenweg“. E-Mail- und Internetadressen liegen unter example.org (z. B. `service@stadtwerke.example.org`) statt unter der Endung `.example`. Bereits angelegte Beispiel-Mappen bleiben, wie sie sind.

## 1.7.1

- Kurzbeschreibung in Alltagssprache, ohne Fachwörter (dms-registry #80).

## 1.7.0

- Organisation: **Eigene Organisation** (Ja/Nein, Vorgabe nein, dms-registry #158, DMS #995) – so weiß Ablago, wer „wir“ sind: für Datenschutz-Auskünfte, den Briefkopf von Vorlagen und die Erkennung (die eigene Organisation ist nie Absender eingehender Post). Ändern kann es nur, wer Ablago verwaltet. Mehrere eigene Organisationen sind möglich (privat und Gewerbe, zwei Firmen) – das ist nur eine Zuordnung.
- Organisation: neuer Abschnitt **Datenschutz** in den Stammdaten, nur bei einer eigenen Organisation zu sehen: **Verantwortlicher** (die Organisation selbst oder eine Person) und **Datenschutzbeauftragter** (Person, nur wenn es einen gibt). Keine Rechtsberatung.
- Organisation: Name, Telefon, Fax, E-Mail, Internetseite und Anschrift nennen ihre Bedeutung jetzt ausdrücklich (`erkennung.art`); darüber liest Ablago die Angaben einer eigenen Organisation. Für die Erkennung ändert sich nichts.
- Beschreibung: AGB und Preislisten mit ihrem Stand im Namen unter *Dokumente* ablegen.
- Kurzanleitung „So nutzt du es“ für den Katalog und Ablago (dms-registry #164).
- Braucht **Ablago 0.238.0** (eigene Organisation). Herausgeber `app.ablago` im Manifest.

## 1.6.1

- Person: Bei **Niederlassung** erscheinen nur noch die Niederlassungen der gewählten **Organisation** (Auswahlfilter, dms-registry #139). Ist die Organisation leer, erscheinen alle wie bisher.
- Neu gewählt muss die Niederlassung zur Organisation passen, sonst lehnt Ablago das Speichern ab – für dieses Paar richtig, denn eine Zweigstelle gehört zu genau einer Organisation. Bestehende Personen bleiben gültig; passen ihre Angaben nicht zusammen, zeigt Ablago ab 0.225.0 am Feld und über den Registern „Niederlassung passt nicht zu „Organisation““ (DMS #887).
- Die Gegenrichtung (Niederlassung gewählt → Organisation füllt sich, DMS #886) kommt mit einer späteren Version. Andere Mappentypen mit Organisation und Niederlassung gibt es in Basis und den Paketen darauf nicht. Braucht kein neueres Ablago.

## 1.6.0

- Neu: Mappentyp **Ablageort** (DMS #883, dms-registry #138) – wo das Papier liegt, verschachtelt („zu Hause › Arbeitszimmer Schrank › roter Ordner“). Felder *Name* (Pflicht), *Liegt in* (Verweis auf einen anderen Ablageort) und *Beschreibung*; Register *Allgemein*, *Enthält*, *Liegt hier* und *Fotos*; Titel `{liegt_in} › {name}`; Ansicht *Ablageorte*. Mit englischen Beschriftungen.
- **Übernahme:** Bisher legte Ablago den Ablageort selbst an. Gibt es ihn in deiner Ablage schon, übernimmt Basis ihn beim Installieren bzw. Update – gleiche Id, alle Ablageorte, Verweise und die vorhandene Ansicht bleiben; danach gehört er zu Basis. Es entsteht kein zweiter Ablageort.
- Andere Pakete verweisen jetzt mit `basis:ablageort` auf ihn (statt `dms:ablageort`, das Ablago bis 1.0 als Alias versteht).
- Braucht Ablago ab 0.212.0 (dort kommt der Ablageort nicht mehr aus dem Kern). Organisation, Niederlassung und Person sind unverändert.

## 1.5.0

- Neu: **englische Beschriftungen** für Mappentypen, Felder, Auswahlwerte, Register und Ansichten (`beschriftungen.en`, Registry #116 und #135). Ablago ab 0.200.0 zeigt sie, wenn jemand Englisch gewählt hat; ein Update ergänzt sie an installierten Mappentypen, ohne eigene Beschriftungen zu überschreiben. Ältere Ablago-Versionen übergehen sie – dafür braucht es kein höheres `dms`. Gespeicherte Werte ändern sich nicht.

## 1.4.2

- Text: Hinweis am Geburtstag – eine jährliche Erinnerung legt man seit Ablago 0.177.0 als Automatisierung „Datum erreicht“ an.

## 1.4.1

- Texte: Das Programm heißt jetzt **Ablago** (dms-registry #111). Inhalt, Rechte und Verhalten sind unverändert.

## 1.4.0

- Neu: **gleichbedeutende Wörter** für die Suche (DMS #356) – wer „Rechnung“ sucht, findet auch „Beleg“; dazu Quittung/Kassenbon/Kassenzettel, Vertrag/Vereinbarung, Kündigung/Beendigung, Police/Versicherungsschein, Mahnung/Zahlungserinnerung, Gutschrift/Erstattung, Lastschrift/Abbuchung und Anschrift/Adresse. Nur allgemeine Wörter; fachliche bringen die Fachpakete mit (z. B. Fahrzeuge, Vermietung).
- Braucht DMS ab 0.127.0 (Wortlisten). Mappentypen, Sichten und Beispiele sind unverändert.

## 1.3.0

- **Formate** (dms-registry #55, DMS #535): Telefon, Fax und Mobil prüft das DMS als Telefonnummer, E-Mail als E-Mail-Adresse, Internetseite als Internetseite und die IBAN der Organisation mit Länge und Prüfziffer. Die PLZ hat in Deutschland genau 5 Ziffern; steht im Feld *Land* ein anderes Land, ist sie frei. Am Handy erscheint die passende Tastatur, Telefon und E-Mail lassen sich antippen.
- Person: Der **Geburtstag** darf nicht in der Zukunft liegen.
- Braucht DMS ab 0.121.0. Gespeicherte Angaben bleiben gültig; das Update übernimmt Formate und Grenzen nur an Feldern, an denen du in der Werkbank nichts davon eingestellt hast. Welche Angaben nicht passen, zeigt Werkbank → Wartungsoperationen.

## 1.2.0

- **Erkennung** (dms-registry #49, DMS #336/#391): Die Felder sind „für die Erkennung“ markiert. Post wird so ohne eigene Einrichtung dem richtigen Absender zugeordnet – an Kundennummer, IBAN, Umsatzsteuer-Id, E-Mail-Adresse bzw. -Domain, Internetseite, Telefon oder Name. „Visitenkarte scannen“ füllt bei einer Person Name, Funktion, Organisation, Telefon, Mobil, E-Mail und Anschrift.
  - Organisation: Name, Kürzel, Kundennummer (mit Erkennungshinweis), Telefon, Fax, E-Mail, Internetseite, Anschrift.
  - Niederlassung: Organisation, Name, Nummer, Kontakt und Anschrift. Person: Vorname, Nachname, Funktion, Organisation, Telefon, Mobil, E-Mail, Anschrift.
- Neu in Organisation: Felder **IBAN** und **Umsatzsteuer-Id** (Register Stammdaten) – starke Merkmale für die Erkennung.
- Braucht DMS ab 0.113.0. Das Update ergänzt die beiden Felder und übernimmt die Markierung nur an Feldern, an denen du in der Werkbank nichts zur Erkennung eingestellt hast.

## 1.1.1

- Lizenz: ab dieser Version **Apache-2.0** (vorher MIT), wie alle Pakete von motom001. Inhalt unverändert.

## 1.1.0

- Neu: Mappentyp **Niederlassung** (Filiale, Zweigstelle, Praxis, Außenstelle einer Organisation) mit eigener Anschrift, Kontakt und Ansprechpartnern.
- Neu: Mappentyp **Person** (Kontakt – kein Benutzer des DMS) mit Beziehung, Arbeit (Organisation, Niederlassung, Funktion), Kontakt und Anschrift.
- Organisation: neue Register **Niederlassungen** und **Ansprechpartner**; Register „Protokoll“ heißt wie im DMS „Historie“ (nur bei Neuinstallation – vorhandene hat das DMS schon umbenannt).
- Neue Sichten *Niederlassungen*, *Personen* mit *Familie und Freunde* und *Ansprechpartner*.
- Beispiele: Sparkasse Musterstadt mit zwei Filialen, eine Kundenberaterin, ein Hausarzt, Oma Muster – mit Verweisen untereinander.
- Braucht DMS ab 0.79.0 (Verweise zwischen Beispielen). Das Update von 1.0.0 ergänzt nur; vorhandene Organisationen bleiben unverändert.

## 1.0.0

- Erste Fassung.
