# Änderungen

## 1.0.0

- Erste Fassung: Russisch (`rus.traineddata` aus tessdata_fast, derselbe Stand wie im Paket Texterkennung) für das Paket Texterkennung ab 2.0.0.
