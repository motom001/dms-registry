# Änderungen

## 1.9.0

- **„Woran man ihn erkennt“ kürzer** (dms-registry #267): je Mappentyp vier bis sechs Wörter, die fast jedes Dokument dieses Typs enthält, statt langer Listen. Lange Listen sprachen bei Ablago oft gegen den richtigen Typ, weil jedes Dokument nur wenige ihrer Wörter enthält. Ein Update übernimmt den Text, solange ihr ihn nicht selbst geändert habt.
- **Aus dem Dokument gefüllt:** Einheit beim Zählerstand – steht der Wert wörtlich im Dokument, schlägt Ablago ihn vor.

## 1.8.0

- **„Woran man ihn erkennt“** für jeden Mappentyp, Deutsch und Englisch (dms-registry #254): Was auf dem Papier steht – Überschriften, Begriffe, Nummern. Hilft Ablago beim Vorschlag „Wohin gehört das?“. Ein Update setzt den Text, solange ihr ihn nicht selbst geändert habt. Zählerstand (Zählernummer, Stand, Ablesedatum) und Wartung lesen ihre Angaben aus dem Dokument.

## 1.7.0

- **Sprechendere Titel** (dms-registry #256, Thomas 24.11.2026): Zählerstand (mit Ablesedatum). Lange Namen werden auf 25 Zeichen gekürzt. Gilt für neue Installationen – Ablago übernimmt eine geänderte Titel-Vorlage beim Update nicht.

## 1.6.1

- **Mehrzahl** für die Mappentypen (dms-registry #223): Listen zeigen jetzt z. B. „12 Zählerstände“ statt „12 × Zählerstand“ (ab Ablago 0.302.0, ältere ignorieren es). Ein Update setzt die Mehrzahl nur, wo du noch keine eingetragen hast.
- **Treffendere Symbole** der Ansichten aus den 259 Symbolen von Ablago 0.304 (dms-registry #230): Immobilien (Grundstück), Zählerstände (Zähler), „Wartung fällig“ mit Kalender und Uhr. Ältere Ablago-Versionen zeigen ein neues Symbol einfach nicht.

## 1.6.0

- Ansichten mit Symbolen: *Haus*, darunter *Immobilien*, *Wartungen*, *Zählerstände* und *Wartung fällig*. *Zählerstände dieses Jahr* und *letztes Jahr* entfallen – solche Ansichten legst du dir bei Bedarf selbst an. Ein Update nimmt keine Ansichten weg: In bestehenden Ablagen bleiben weggefallene Ansichten stehen, bis du sie löschst (Thomas, 20.11.2026).

## 1.5.1

- Kurzanleitung „So nutzt du es“ im Katalog und nach der Installation in Ablago (dms-registry #198, motom001/dms#1047).

## 1.5.0

- Der **Wartungsvertrag** an der Wartung ist ein **Vertrag** aus dem Paket Verträge (bisher Vertrag aus Haushalt, dms-registry #163). In einer bestehenden Ablage zeigt das Feld von selbst dorthin, sobald Verträge 1.1.0 die Verträge aus Haushalt übernommen hat.
- Hängt jetzt ab von **Basis** und **Verträge 1.1.0** statt Haushalt; braucht Ablago 0.243.0.

## 1.4.0

- Neu (Registry #114): **Eigentümer/Vermieter (Person)** an der Immobilie – Verweis auf eine oder mehrere Personen aus Basis, z. B. „ihr beide“ oder die private Vermieterin. Das bisherige Feld heißt jetzt **Eigentümer/Vermieter (Organisation)** und bleibt für Gesellschaften, Erbengemeinschaften und die Hausverwaltung. Ein Update ergänzt nur das neue Feld; gespeicherte Werte bleiben, wo sie sind.

## 1.3.1

- Das Feld **Verbleib Originaldokumente** verweist auf den Ablageort aus dem Paket **Basis** (`basis:ablageort` statt `dms:ablageort`, dms-registry #138, Ablago #883). Braucht Basis ab 1.6.0 und Ablago ab 0.212.0. In einer bestehenden Ablage ändert sich nichts: Basis übernimmt den bisherigen Ablageort mit allen Orten, das Feld zeigt weiter darauf.

## 1.3.0

- Neu: **englische Beschriftungen** für Mappentypen, Felder, Auswahlwerte, Register und Ansichten (`beschriftungen.en`, Registry #116 und #135). Ablago ab 0.200.0 zeigt sie, wenn jemand Englisch gewählt hat; ein Update ergänzt sie an installierten Mappentypen, ohne eigene Beschriftungen zu überschreiben. Ältere Ablago-Versionen übergehen sie – dafür braucht es kein höheres `dms`. Gespeicherte Werte ändern sich nicht.

## 1.2.0

- Neu: **vorgefertigte Automatisierungen** für jede Frist (1). Seit Ablago 0.177.0 erinnert ein Datumsfeld nicht mehr selbst – die Automatisierung „Datum erreicht“ tut es, Vorlaufzeit, Empfänger und Text stellst du selbst ein. Beim Installieren fragt Ablago, welche gleich eingeschaltet werden (Vorgabe: alle); bei einem Update ersetzt die mitgelieferte die übernommene Erinnerung, solange du sie nicht geändert hast.
- Braucht Ablago ab 0.177.0.

## 1.1.1

- Texte: Das Programm heißt jetzt **Ablago** (dms-registry #111). Inhalt, Rechte und Verhalten sind unverändert.

## 1.1.0

- **Formate** (dms-registry #55, DMS #535): Neues Feld **Land** an der Immobilie (Vorgabe Deutschland). Die PLZ hat in Deutschland genau 5 Ziffern, bei einem anderen Land ist sie frei.
- **Zuletzt am** (Wartung) und **Abgelesen am** (Zählerstand) dürfen nicht in der Zukunft liegen.
- Braucht DMS ab 0.121.0. Gespeicherte Angaben bleiben gültig; das Update ergänzt das Feld Land und übernimmt Formate und Grenzen nur an Feldern, an denen du nichts davon eingestellt hast.

## 1.0.2

- Lizenz: ab dieser Version **Apache-2.0** (vorher MIT), wie alle Pakete von motom001. Inhalt unverändert.

## 1.0.1

- Beispiele zeigen jetzt auf die Immobilie: Wartungen und Zählerstände hängen am Einfamilienhaus Musterweg 1.
- Braucht DMS ab 0.79.0 (Verweise zwischen Beispielen).

## 1.0.0

- Erste Fassung.
